# Ciao Bangla Android App

এই Android Studio project-এ আপনার Premium Splash Animation-সহ HTML অ্যাপটি WebView-এর মাধ্যমে প্যাক করা হয়েছে। লোগো HTML-এর ভেতরে embedded আছে; launcher icon-এও আপনার Ciao logo ব্যবহার করা হয়েছে।

## APK বানানোর ধাপ
1. কম্পিউটারে Android Studio ইনস্টল করুন: https://developer.android.com/studio
2. Android Studio খুলে **Open** নির্বাচন করুন এবং এই `CiaoBangla_Android_Project` ফোল্ডারটি খুলুন।
3. Gradle Sync শেষ হতে দিন। Android SDK Platform 35 চাইলে SDK Manager থেকে ইনস্টল করুন।
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** নির্বাচন করুন।
5. APK পাওয়া যাবে: `app/build/outputs/apk/debug/app-debug.apk`

## নোট
- এই পরিবেশে Android SDK/Gradle build tool ইনস্টল নেই, তাই এখানে সরাসরি APK compile করা যায়নি। এটি Android Studio-তে খোলার মতো সম্পূর্ণ source project।
- অ্যাপটি ইন্টারনেট ব্যবহার করতে পারে, কারণ মূল HTML-এ Tailwind CDN রয়েছে এবং কিছু অনলাইন সুবিধা থাকতে পারে।
- শিক্ষার্থীর অগ্রগতি WebView local storage-এ থাকে; অ্যাপের ডেটা মুছলে তা হারাতে পারে।
